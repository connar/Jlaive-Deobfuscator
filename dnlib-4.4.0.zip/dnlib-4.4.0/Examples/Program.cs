namespace dnlib.Examples {
	class Program {
		static void Main(string[] args) {
			// Just uncomment whatever you want to debug
// 			Example1.Run();
// 			Example2.Run();
// 			Example3.Run();
// 			Example4.Run();
// 			Example5.Run();
// 			Example6.Run();
			Example7.Run();
		}
	}
}
