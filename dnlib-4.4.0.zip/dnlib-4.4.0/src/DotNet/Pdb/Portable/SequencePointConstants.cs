// dnlib: See LICENSE.txt for more info

namespace dnlib.DotNet.Pdb.Portable {
	static class SequencePointConstants {
		public const int HIDDEN_LINE = 0xFEEFEE;
		public const int HIDDEN_COLUMN = 0;
	}
}
