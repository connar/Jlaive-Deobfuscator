// dnlib: See LICENSE.txt for more info

namespace dnlib.DotNet {
	/// <summary>
	/// Extension methods
	/// </summary>
	public static partial class Extensions {
	}
}
